package me.matteogiovagnotti.springilmiofotoalbum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringilmiofotoalbumApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringilmiofotoalbumApplication.class, args);
	}

}
