package me.matteogiovagnotti.springilmiofotoalbum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringilmiofotoalbumApplicationTests {

	@Test
	void contextLoads() {
	}

}
